# Databricks notebook source
result = dbutils.jobs.taskValues.get(taskKey="WeekdayLookup", key="weekoutput")

# COMMAND ----------

print(result)

# COMMAND ----------

