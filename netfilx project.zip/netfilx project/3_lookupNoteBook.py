# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Array Parameter

# COMMAND ----------

files = [

    {
        "source" : "netflix_directors",
        "sink" : "netflix_directors"
    },
     {
        "source" : "netflix_cast",
        "sink" : "netflix_cats"
    },
      {
        "source" : "netflix_countries",
        "sink" : "netflix_countries"
    },
       {
        "source" : "netflix_category",
        "sink" : "netflix_category"
    },

]

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # creating job utilites for returning ARRAY

# COMMAND ----------

dbutils.jobs.taskValues.set(key = "my_arr", value = files)

# COMMAND ----------

