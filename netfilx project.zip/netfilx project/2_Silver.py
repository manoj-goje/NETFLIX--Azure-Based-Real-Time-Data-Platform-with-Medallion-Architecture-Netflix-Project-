# Databricks notebook source
# MAGIC %md
# MAGIC ### parameters

# COMMAND ----------

dbutils.widgets.text("source","")
dbutils.widgets.text("sink","")

# COMMAND ----------

source = dbutils.widgets.get("source")
destination = dbutils.widgets.get("sink")

# COMMAND ----------

df = spark.read.format("csv")\
    .option("header", "true")\
        .option("inferSchema", "true")\
            .load(f"abfss://bronze@netfilxprojectproject.dfs.core.windows.net/{source}")

# COMMAND ----------

df.display()

# COMMAND ----------

df.write.format("delta")\
    .mode("append")\
        .option("path",f"abfss://silver@netfilxprojectproject.dfs.core.windows.net/{destination}")\
            .save()

# COMMAND ----------

